#include "markov.h"

#define SNF               1
#define OLIGO_FREQUENCY   2
#define TRANSITION_MATRIX 3


int bernoulli(Markov &m, double *priori){
	m.dealloc();
	m.alloc(0);
	m.S[0] = 1.0;
	for(int i=0; i<ALPHABET_SIZE; i++){
		m.priori[i] = priori[i];
		m.T[0][i] = priori[i];
	}
	return 1;
}


int load_inclusive(Markov &m, string filename){
	m.dealloc();

    ifstream f;
    f.open(filename.c_str());
    if (!f) {
        cerr << "Unable to open file '" << filename << "'" << endl;
		exit(1);
    }
	string line;
	char const *buffer;
	int order = -1;
	int step = 0;
	int s = 0;
	int t = 0;
	float val[4];
	while (getline(f, line)){
		buffer = line.c_str();
		if (line[0] == '#'){
			if (sscanf(buffer, "%*s %*s %d", &order) == 1)
				m.alloc(order);
			else if (line == "#snf")
				step = SNF;
			else if (line == "#oligo frequency")
				step = OLIGO_FREQUENCY;
			else if (line == "#transition matrix")
				step = TRANSITION_MATRIX;
		}else{
			if (order == -1)
				break;
			if (step == SNF){
				if (sscanf(buffer, "%f %f %f %f", &val[0], &val[1], &val[2], &val[3]) == 4){
					m.priori[0] = (double) val[0];
					m.priori[1] = (double) val[1];
					m.priori[2] = (double) val[2];
					m.priori[3] = (double) val[3];
				}
			}else if (step == OLIGO_FREQUENCY){
				 if (s < m.msize){
				 	sscanf(buffer, "%f", &val[0]);
				 	m.S[s] = (double) val[0];
				 	s++;
				 }
			}else if (step == TRANSITION_MATRIX){
				if (t < m.msize){
					if (sscanf(buffer, "%f %f %f %f", &val[0], &val[1], &val[2], &val[3]) == 4){
						m.T[t][0] = (double) val[0];
						m.T[t][1] = (double) val[1];
						m.T[t][2] = (double) val[2];
						m.T[t][3] = (double) val[3];										
						t++;
					}
				}
			}
		}
	}
    f.close();

	// special case when order=0
	if (m.order == 0){
		m.S[0] = 1.0;
	}
	if (m.order == -1)
		return 0;
	else
		return 1;
}


