#include "array.h"

void print_matrix(double **data, int I, int J){
	cout << endl;
	for(int i=0; i<I; i++){

		for(int j=0; j<J; j++){
			 cout << data[i][j] << "\t";
		}
	cout << endl;
	}
}

